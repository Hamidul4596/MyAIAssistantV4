package com.myaiaassistant.v4

import android.content.Intent
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import java.util.*

class MainActivity : ComponentActivity() {
    private val history = mutableStateListOf<Pair<String,String>>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                AssistantScreen(
                    history = history,
                    onListen = { startVoiceInput() },
                    onOpenWeb = { startActivity(Intent(Intent.ACTION_VIEW, android.net.Uri.parse("https://www.google.com"))) }
                )
            }
        }
    }

    private fun startVoiceInput() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
        }
        runCatching { startActivityForResult(intent, 1001) }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 1001 && resultCode == RESULT_OK) {
            val text = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!text.isNullOrBlank()) history.add("You" to text)
        }
    }
}

@Composable
fun AssistantScreen(
    history: List<Pair<String,String>>,
    onListen: () -> Unit,
    onOpenWeb: () -> Unit
) {
    var text by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Text("My AI Assistant V4", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        Text("বাংলা বা English-এ বলুন")
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(value=text, onValueChange={text=it}, modifier=Modifier.fillMaxWidth(), label={Text("Command")})
        Spacer(Modifier.height(10.dp))
        Row(horizontalArrangement=Arrangement.spacedBy(8.dp)) {
            Button(onClick=onListen) { Text("🎙 Voice") }
            OutlinedButton(onClick=onOpenWeb) { Text("Web") }
        }
        Spacer(Modifier.height(16.dp))
        history.takeLast(8).forEach { (who,msg) ->
            Text("$who: $msg", modifier=Modifier.padding(vertical=4.dp))
        }
    }
}
