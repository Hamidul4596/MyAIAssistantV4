package com.myaiaassistant.v4.tools

import android.content.Context
import android.content.Intent
import android.net.Uri

/**
 * Handles the "open app / search web" actions listed in the V4 feature list.
 * Deliberately narrow: it only launches apps by known package name or opens
 * URLs, it never runs shell commands.
 */
object AppLauncher {

    // A small, explicit allow-list. Add more (package name) pairs as needed.
    private val KNOWN_APPS = linkedMapOf(
        "youtube" to "com.google.android.youtube",
        "ইউটিউব" to "com.google.android.youtube",
        "chrome" to "com.android.chrome",
        "ক্রোম" to "com.android.chrome",
        "settings" to "com.android.settings",
        "সেটিংস" to "com.android.settings",
        "gmail" to "com.google.android.gm",
        "জিমেইল" to "com.google.android.gm",
        "maps" to "com.google.android.apps.maps",
        "map" to "com.google.android.apps.maps",
        "ম্যাপ" to "com.google.android.apps.maps",
        "whatsapp" to "com.whatsapp",
        "হোয়াটসঅ্যাপ" to "com.whatsapp",
        "facebook" to "com.facebook.katana",
        "ফেসবুক" to "com.facebook.katana",
        "instagram" to "com.instagram.android",
        "ইনস্টাগ্রাম" to "com.instagram.android",
        "telegram" to "org.telegram.messenger",
        "টেলিগ্রাম" to "org.telegram.messenger",
        "calculator" to "com.google.android.calculator",
        "ক্যালকুলেটর" to "com.google.android.calculator",
        "camera" to "com.android.camera2",
        "ক্যামেরা" to "com.android.camera2",
        "phone" to "com.google.android.dialer",
        "ফোন" to "com.google.android.dialer",
        "messages" to "com.google.android.apps.messaging",
        "মেসেজ" to "com.google.android.apps.messaging"
    )

    sealed class LocalResult {
        data object Handled : LocalResult()
        data class Reply(val text: String) : LocalResult()
        data object NotHandled : LocalResult()
    }

    fun handleLocally(context: Context, rawText: String): LocalResult {
        val text = rawText.trim().lowercase()

        for ((keyword, packageName) in KNOWN_APPS) {
            if (text.contains(keyword)) {
                return if (launchApp(context, packageName)) LocalResult.Handled
                else if (keyword == "youtube" || keyword == "ইউটিউব") {
                    if (openWebSearch(context, "YouTube")) LocalResult.Handled else LocalResult.NotHandled
                } else LocalResult.Reply("এই অ্যাপটি আপনার ফোনে ইনস্টল করা নেই।")
            }
        }

        if (text.contains("search") || text.contains("সার্চ") || text.contains("খুঁজে") || text.contains("অনুসন্ধান")) {
            val query = when {
                text.contains("search") -> rawText.substringAfter("search", "").trim()
                text.contains("সার্চ") -> rawText.substringAfter("সার্চ", "").trim()
                text.contains("খুঁজে") -> rawText.substringAfter("খুঁজে", "").trim()
                else -> rawText
            }.ifBlank { rawText }
            return if (openWebSearch(context, query)) LocalResult.Handled else LocalResult.NotHandled
        }

        return LocalResult.NotHandled
    }

    @Deprecated("Use handleLocally")
    fun tryHandleLocally(context: Context, rawText: String): Boolean =
        handleLocally(context, rawText) is LocalResult.Handled

    private fun launchApp(context: Context, packageName: String): Boolean {
        val intent = context.packageManager.getLaunchIntentForPackage(packageName) ?: return false
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        return true
    }

    private fun openWebFallback(context: Context, query: String): Boolean =
        openWebSearch(context, query)

    private fun openWebSearch(context: Context, query: String): Boolean {
        return try {
            val uri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))
            context.startActivity(Intent(Intent.ACTION_VIEW, uri).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (e: Exception) {
            false
        }
    }

    fun openUrl(context: Context, url: String) {
        context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }
}
